var YourCounter = 20;
var EnemyCounter = 20;
var Mode = "0"; //0 = 1v1, 1 = Commander

function YourIncrease() {
  YourCounter++;
  document.getElementById('YourCount').innerHTML = YourCounter;
  saveLife(); 
}

function YourDecrease() {
  YourCounter--
  document.getElementById('YourCount').innerHTML = YourCounter;
  saveLife();
}

function EnemyIncrease() {
  EnemyCounter++;
  document.getElementById('EnemyCount').innerHTML = EnemyCounter;
  saveLife();
}

function EnemyDecrease() {
  EnemyCounter--;
  document.getElementById('EnemyCount').innerHTML = EnemyCounter;
  saveLife();
}  

function Reset() {
  if (true) { //confirm("Reset life totals to 20?")) {
    YourCounter = 20;
    EnemyCounter = 20;
    document.getElementById('YourCount').innerHTML = YourCounter;
    document.getElementById('EnemyCount').innerHTML = EnemyCounter;
    setMode(0);
    saveLife();
  }
}

function Commander() {
  if (true) {//confirm("Set your life total to 40?")) {
    YourCounter = 40;
    EnemyCounter = 0;
    document.getElementById('YourCount').innerHTML = YourCounter;
    document.getElementById('EnemyCount').innerHTML = EnemyCounter;
    setMode(1);
    saveLife();
  }
}

function setMode(i) {
  Mode = i;
  if (Mode == 0) {
    document.getElementById('EnemyName').innerHTML = "Versus";
  } else {
    document.getElementById('EnemyName').innerHTML = "Poison";
  }
}

function supportsLocalStorage() {
  try {
    return 'localStorage' in window && window['localStorage'] !== null;
  } catch (e) {
    return false;
  }
}

function saveLife() {
  if (!supportsLocalStorage()) { return false; } 
  window.localStorage["YourCounter"] = YourCounter;
  window.localStorage["EnemyCounter"] = EnemyCounter;
  window.localStorage["Mode"] = Mode;
}

function prepareOnClicks() {
    document.getElementById('YourUp').onclick = function() { YourIncrease() }
    document.getElementById('YourDown').onclick = function() { YourDecrease() }
    document.getElementById('EnemyUp').onclick = function() { EnemyIncrease() }
    document.getElementById('EnemyDown').onclick = function() { EnemyDecrease() }
    document.getElementById('reset').onclick = function() { Reset() }
    document.getElementById('commander').onclick = function() { Commander() }
}

window.onload = function() {
  prepareOnClicks();
  var item = document.getElementByID('YourDown');
  var draggie = new Draggabilly( item, {
    axis: 'y'
  });  
  if (!supportsLocalStorage()) { return false; } 
  if (!window.localStorage["YourCounter"]) { return false }
  YourCounter = window.localStorage["YourCounter"];
  if (!window.localStorage["EnemyCounter"]) { return false }
  EnemyCounter = window.localStorage["EnemyCounter"];
  document.getElementById('YourCount').innerHTML = YourCounter;
  document.getElementById('EnemyCount').innerHTML = EnemyCounter;
  if (!window.localStorage["Mode"]) { return false }
  Mode = window.localStorage["Mode"];
  setMode(Mode);
}