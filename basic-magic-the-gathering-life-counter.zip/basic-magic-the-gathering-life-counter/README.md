# Basic Magic: The Gathering Life Counter

A Pen created on CodePen.io. Original URL: [https://codepen.io/Xand0r/pen/LYpvdP](https://codepen.io/Xand0r/pen/LYpvdP).

Diving into HTML5 with a simple life-counting tracker. Designed for use in one-on-one matches of Magic: The Gathering. Includes a bit of responsive design for landscape and portait modes on phones or tablets.